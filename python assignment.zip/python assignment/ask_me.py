print("am ready to help")
NAME=str(input("Can You please enter your name : "))
print("Hello",NAME,"How can i help you")