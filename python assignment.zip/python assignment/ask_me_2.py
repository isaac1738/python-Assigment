from unicodedata import name


NAME=str(input("Can You please enter name : "))


if NAME =='NAME':
    print("Hello",NAME)


else:
   
   print("Hello stranger")


   



